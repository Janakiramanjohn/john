

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable,Text,Text,IntWritable> {
	public void map(LongWritable mInpKey,Text mInpVal,Context con) throws IOException, InterruptedException{
		String inpVal = mInpVal.toString();
		String[] eachVal = inpVal.split(" ");
		Text mOutKey = new Text(eachVal[3]);
		Text mOutVal = new Text(eachVal[2]);
		//con.write(mOutKey, mOutVal);
		
	//	Text word = new Text();
		IntWritable i = new IntWritable(1);
		
		StringTokenizer st=new StringTokenizer(inpVal);
		
		while(st.hasMoreTokens())
		{
			
			mOutKey.set(st.nextToken());
			con.write(mOutKey,i);
		}
		
	}

}
