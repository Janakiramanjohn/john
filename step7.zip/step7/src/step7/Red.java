package step7;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;

public class Red extends Reducer<Text,Text,Text,Text>{
	
	
	public void reduce(Text inpk,Iterable<Text> inpv,Context c) throws IOException, InterruptedException{
		for(Text x:inpv){
			c.write(x,null);	
		
		}
	}
}
