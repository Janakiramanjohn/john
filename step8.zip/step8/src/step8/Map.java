package step8;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		
		String line=inpv.toString();
		String logname=line.split(" ")[3];
		
		
		c.write(new Text(logname),new IntWritable(1));
		
	}
		
		
	}
