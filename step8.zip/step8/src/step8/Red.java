package step8;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class Red extends Reducer<Text,IntWritable,Text,IntWritable>{
	
public void reduce(Text inpk,Iterable<IntWritable> inpv,Context c) throws IOException, InterruptedException{

int count=0;
for(IntWritable x:inpv)
{
	count=count+1;
}
c.write(inpk, new IntWritable(count));
}
}
