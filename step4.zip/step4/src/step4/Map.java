package step4;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Map  extends Mapper<LongWritable, Text, Text, DoubleWritable>{
	public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
		String value = inpv.toString();
		String eachval[] = value.split(",");
 	   double val = Double.parseDouble(eachval[3]);
 	  c.write(new Text(eachval[2]), new DoubleWritable(val));
 	   
 	  
    }
}
