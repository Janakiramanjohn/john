import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class MyPartitioner extends Partitioner<Text, Text> {

	@Override
	public int getPartition(Text arg0, Text arg1, int arg2) {
		// TODO Auto-generated method stub
		String log=arg0.toString();
		if(log.equals("[ERROR]"))
		return 0;
		else if(log.equals("[DEBUG]"))
			return 1;
		else if(log.equals("[TRACE]"))
			return 2;
		else
			return 3;
		
	}

	
	
}
