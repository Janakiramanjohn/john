

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class task9reducer extends Reducer<Text, Text, Text, Text>{
	public void reduce(Text inpk, Iterable<Text> inpv, Context c) throws IOException, InterruptedException{
		double max = 0;
		double val = 0;
		String name = " ";
		for(Text value:inpv){
			String[] eachVal = value.toString().split(":");
			val = Double.parseDouble(eachVal[1]);
			if(max<val){
				max = val;
				name = eachVal[0];
				
			}
		}
		
		c.write(new Text(name), new Text(Double.toString(max)));
	}

}
