

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class task9combiner extends Reducer<Text, Text, Text, Text>{
	public void reduce(Text inpk, Iterable<Text> inpv, Context c) throws IOException, InterruptedException{
		double amount = 0.0;
		for(Text amt : inpv){
			amount += Double.parseDouble(amt.toString());
		}
		Text val = new Text(Double.toString(amount));
		c.write(new Text("dummy"), new Text(inpk+":"+val));
	}

}
