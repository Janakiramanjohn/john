package nametask;

public class myMapper {

}
