package wordcount;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mp extends Mapper<LongWritable, Text, Text, IntWritable> {
	public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value = inpv.toString();
	Text word = new Text();
	IntWritable i = new IntWritable(1);
	
	StringTokenizer st=new StringTokenizer(value);
	
	while(st.hasMoreTokens())
	{
		
		word.set(st.nextToken());
		c.write(word, i);
	}
	
	
	}

}
