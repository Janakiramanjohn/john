
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, Text, DoubleWritable> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		Integer u =c.getConfiguration().getInt("User",4007024);
		String uid = inpK.getid();
		double amt = inpV.getAmt();
		int i = Integer.parseInt(uid);
		if(i==u){
			c.write(new Text(inpK.getid()),new DoubleWritable(amt));
		}
}
}