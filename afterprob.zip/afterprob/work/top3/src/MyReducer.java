
import java.util.List;
import java.io.IOException;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyReducer extends Reducer<Text, Text, Text, IntWritable> {
	public void reduce(Text inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
	    Map<String,Integer> hm=new HashMap<String,Integer>();
		int max=0,value=0;
		String module=" ";
		for(Text each: inpV){
			String[] eachVal = each.toString().split(":");
			value=Integer.parseInt(eachVal[1]);
			module=eachVal[0];
			hm.put(module, value);
	}
		Set<java.util.Map.Entry<String, Integer>> set = hm.entrySet();
		List<java.util.Map.Entry<String, Integer>> list = new ArrayList<java.util.Map.Entry<String, Integer>>(set);
        Collections.sort( list, new Comparator<Map.Entry<String, Integer>>()
        {
            public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
            {
                return (o2.getValue()).compareTo( o1.getValue() );
            }
        } );
        int flag=0;
        for(Map.Entry<String, Integer> entry:list){
        	c.write(new Text(entry.getKey().toString()),new IntWritable(entry.getValue()));
        	flag++;
        	if(flag==3){break;}
        }
 	
		
}
}
