
import java.io.IOException;



import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<LongWritable,Text,Text,Text>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		
		String value=inpv.toString();
		String[] data=value.split(" ");
		String module=data[2];
		
		c.write(new Text(module), new Text("1"));
		
	}

}






