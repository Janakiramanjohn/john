
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class MyCombiner extends Reducer<Text,Text, Text, Text> {
	public void reduce(Text inpK,Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		//String module=inpK.toString();
		int count=0;
		
		for(@SuppressWarnings("unused")Text x: inpV){
			count=count+1;
		}
		c.write(new Text("Dummy Key"), new Text(inpK+":"+count));
	}

}