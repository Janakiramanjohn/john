

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, Text, IntWritable> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		Double minamt = (double) c.getConfiguration().getInt("Lower", 175);
		Double maxamt = (double) c.getConfiguration().getInt("Upper", 200);
		Double amt = inpV.getAmt();
 	   if(amt>minamt && amt<maxamt){
			c.write(new Text("Output"),new IntWritable(1));
		}
	}

}
